<div>
    <div style="text-align: center; background: #ddd; padding: 2px">
        <h1><?php echo e(env('APP_NAME')); ?></h1>
    </div>
    <h2 style="margin-bottom: 10px"><?php echo e($request->name); ?></h2>
    <h3>
        <?php echo e($request->email); ?> <br>
        <?php echo e($request->phone); ?> <br>
        <?php echo e($request->company); ?>

    </h3>
    <p><?php echo e($request->message); ?></p>
</div><?php /**PATH /home/abedin/Company/brainShare/resources/views/email/message.blade.php ENDPATH**/ ?>