<?php $__env->startSection('title'); ?>
    <title>Create Project</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
    <h1> Create Project</h1>
    <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>
<?php if($errors->any()): ?>
<div class="alert alert-danger">
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>  
<section>
    <a href="#createProject" data-toggle="modal" class="btn btn-primary px-5">Create Project</a>
    <a href="#c_completeProject" data-toggle="modal" class="btn btn-primary px-5">Add Complete Project</a>
    <div class="row">
        <h2 class="p-3 m-0">Our Projects</h2>
    </div>
    <div class="row py-4">
        <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-ms-6 col-12 col-md-3">
            <img width="100%" src="<?php echo e(asset($item->image)); ?>" alt="">
            <h5 class="bg-light text-center p-2"><?php echo e($item->category->name); ?> <a href="#createProject<?php echo e($item->id); ?>" data-toggle="modal">Edit</a></h5>
        </div>

        <div class="modal fade" id="createProject<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
            <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
        
                <form action="<?php echo e(route('project.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                    <div class="modal-body">
                        <div class="form-group text-center">
                            <img width="50%" src="<?php echo e(asset($item->image)); ?>" alt="">
                        </div>
                        <div class="form-group">
                            <label for="type">Project Type</label>
                            <select name="Project_type" class="form-control">
                                <option value="" selected disabled>Select Project Type</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e(encrypt($cat->id)); ?>" <?php echo e($item->category_id == $cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Project Photo</label>
                            <input type="file" class="form-control-file" name="image">
                        </div>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                    </div>
        
                </form>
            </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row">
        <h2 class="p-3 m-0">Our Complete Projects</h2>
    </div>
    <div class="row">
        <?php $__currentLoopData = $completeProject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-6 col-md-3 text-right">
            <img width="100%" src="<?php echo e(asset($item->image)); ?>" alt="">
            <a href="" onclick="event.preventDefault();
                        document.getElementById('delete<?php echo e($item->id); ?>').submit()" class="btn btn-danger">Delete</a>
        </div>
        <form id="delete<?php echo e($item->id); ?>" action="<?php echo e(route('project.destroy', $item->id)); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?> </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>

<div class="modal fade" id="createProject" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>

        <form action="<?php echo e(route('project.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="modal-body">
                <div class="form-group">
                    <label for="type">Project Type</label>
                    <select name="Project_type" class="form-control">
                        <option value="" selected disabled>Select Project Type</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(encrypt($item->id)); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <input type="hidden" name="project" value="dfhh fhfh flkfj">
                <div class="form-group">
                    <label for="">Project Photo</label>
                    <input type="file" class="form-control-file" name="image">
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
            </div>

        </form>
    </div>
    </div>
</div>

<div class="modal fade" id="c_completeProject" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
    <div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        </div>

        <form action="<?php echo e(route('project.store')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="modal-body">
                <div class="form-group">
                    <label for="">Project Photo</label>
                    <input type="file" class="form-control-file" name="image">
                </div>
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
            </div>

        </form>
    </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/createProject.blade.php ENDPATH**/ ?>