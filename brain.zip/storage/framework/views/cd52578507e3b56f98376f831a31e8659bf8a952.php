<?php $__env->startSection('title'); ?>
    <title>Design Service page</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
    <h1>Edit Service Info</h1>
    <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>
<section>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>  
    <div class="col-12">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('service_content.update', $serviceContent->id)); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
            <div class="row">
                <div class="col-8 text-center m-auto">
                    <img width="100%" src="<?php echo e(asset($serviceContent->service_img)); ?>" alt="">
                </div>
                <div class="form-group col-12 col-md-6">
                    <label >Category</label>
                    <select class="form-control" name="cetregory" id="">
                        <option value="" selected disabled>Select Category</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e(encrypt($item->id)); ?>" <?php echo e($serviceContent->category_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-12 col-md-6">
                    <label for="">Chose First Image</label>
                    <input type="file" class="form-control-file" name="serviceImg">
                </div>
                <div class="form-group col-12 ">
                    <label for="serviceCon">Write About Service</label>
                    <textarea name="serviceCon" class="form-control" id="serviceCon" cols="30" rows="5" placeholder="Write About Service"><?php echo e($serviceContent->serviceCon); ?></textarea>
                </div>
                <div class="row col-12 my-3">
                    <div class="col-8 col-md-4 m-auto">
                        <img width="100%" src="<?php echo e(asset($serviceContent->discussion_img_1)); ?>" alt="">
                    </div>
                    <div class="col-8 col-md-4 m-auto">
                        <img width="100%" src="<?php echo e(asset($serviceContent->discussion_img_2)); ?>" alt="">
                    </div>
                </div>
                <div class="form-group col-12 col-md-6">
                    <label for="">Project Discussion photo</label>
                    <input type="file" class="form-control-file" name="discussion_img_1">
                </div>
                <div class="form-group col-12 col-md-6">
                    <label for="">Project Discussion photo</label>
                    <input type="file" class="form-control-file" name="discussion_img_2">
                </div>
                <div class="form-group col-12">
                    <label for="discussion">Project Discussion</label>
                    <textarea name="discussion" class="form-control" id="discussion" cols="30" rows="5" placeholder="Project Discussion"><?php echo e($serviceContent->discussion); ?></textarea>
                </div>
                <div class="form-group col-12">
                    <button class="btn btn-primary px-5" type="submit">Save</button>
                </div>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/editServiceContent.blade.php ENDPATH**/ ?>