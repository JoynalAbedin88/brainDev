<?php $__env->startSection('title'); ?>
    <title>Admin/Dashboard</title>
<?php $__env->stopSection(); ?>
<style>
    td{
        vertical-align: middle !important;
    }
</style>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i> All Post</h1>
      <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>

<section>
    <table class="table table-striped table-hover text-center">
        <thead>
            <tr>
                <th>Title</th>    
                <th>Type</th>
                <th>Image</th>
                <th>Action</th>    
            </tr>   
        </thead>   
        <tbody>
            <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->title); ?></td>    
                <td>Dashboard</td>    
                <td><img width="100px" src="<?php echo e(asset($item->image)); ?>" alt=""></td>    
                <td>
                    <a onclick="event.preventDefault();
                        document.getElementById('restore_form<?php echo e($item->id); ?>').submit()" class="btn btn-primary"><i class="fas fa-undo"></i></a>

                    <a href="" onclick="event.preventDefault();
                                document.getElementById('delete_form<?php echo e($item->id); ?>').submit()" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
                </td>
                <form id="restore_form<?php echo e($item->id); ?>" method="post" action="<?php echo e(route('blog.restore', $item->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                </form> 
                <form id="delete_form<?php echo e($item->id); ?>" method="post" action="<?php echo e(route('blog.forceDelete', $item->id)); ?>">
                    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                </form>   
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
        </tbody> 
    </table>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/blog/trush.blade.php ENDPATH**/ ?>