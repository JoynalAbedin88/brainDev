<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <?php echo $__env->yieldContent('title'); ?>
  
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="<?php echo e(asset('frontend/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/css/icofont.min.css')); ?>" rel="stylesheet">
  
  <link href="<?php echo e(asset('frontend/css/venobox.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/css/owl.carousel.min.css')); ?>" rel="stylesheet">
  <link href="<?php echo e(asset('frontend/css/aos.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"/>

  <!-- Template Main CSS File -->
  <link href="<?php echo e(asset('frontend/css/style.css')); ?>" rel="stylesheet">

</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-none d-lg-block">
    <div class="container d-flex">
      <div class="contact-info mr-auto">
        <i class="icofont-phone"></i> +1 5589 55488 55
        <i class="icofont-envelope"></i><a href="mailto:contact@example.com">contact@example.com</a>
      </div>
      <div class="social-links">
        <a href="#" class="twitter"><i class="icofont-twitter"></i></a>
        <a href="#" class="facebook"><i class="icofont-facebook"></i></a>
        <a href="#" class="instagram"><i class="icofont-instagram"></i></a>
        <a href="#" class="linkedin"><i class="fab fa-linkedin-in"></i></a>
        <a href="#" class="linkedin"><i class="fab fa-google-plus-g"></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header">
    <div class="container d-flex">

      <div class="logo mr-auto">
        <!-- <h1 class="text-light"><a href="<?php echo e(route('front.index')); ?>">Brain <span class="text-danger">Share</span></a></h1> -->
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="<?php echo e(route('front.index')); ?>"><img src="<?php echo e(asset('frontend/images/logoM.png')); ?>" alt="" class="img-fluid"></a>
      </div>

      <nav class="nav-menu d-none d-lg-block">
        <ul>
          <li><a href="<?php echo e(route('front.index')); ?>">Home</a></li>
          <li><a href="<?php echo e(route('front.about')); ?>">About Us</a></li>
          <li class="drop-down"><a href="#">Services</a>
            <ul>
              <?php $__currentLoopData = App\Models\Category::where('what', 2)->orderBy('name', 'asc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><a href="<?php echo e(route('front.service', ['name' => $item->name, 'id' => encrypt($item->id)])); ?>"><?php echo e($item->name); ?></a></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            

          </li>
          <li><a href="<?php echo e(route('front.project')); ?>">Project</a></li>
          <li><a href="<?php echo e(route('front.blog')); ?>">Blog</a></li>
          <li><a href="<?php echo e(route('front.contact')); ?>">Contact</a></li>

        </ul>
      </nav><!-- .nav-menu -->

    </div>
  </header>
  <!-- End Header --><?php /**PATH /home/abedin/Company/brainShare/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>