<?php $__env->startSection('title'); ?>
    <title>Banners</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
      <h1><i class="fa fa-dashboard"></i> Banners</h1>
      <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
      <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>

<section>
<a href="#banner" data-toggle="modal" class="btn btn-primary px-4">Add Banner</a>
    <div class="row">
      <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-10 m-auto">
        <h3 class="mt-4"><?php echo e($item->heading); ?> 

          <a class="mx-2" href="#bannerUp<?php echo e($item->id); ?>" data-toggle="modal">Edit <i class="fas fa-edit"></i></a>

          <a href="<?php echo e(route('banner.destroy', $item->id)); ?>" onclick="event.preventDefault();
            document.getElementById('delete<?php echo e($item->id); ?>').submit()"><i class="fas fa-trash-alt"></i></a>
            <form action="<?php echo e(route('banner.destroy', $item->id)); ?>" id="delete<?php echo e($item->id); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?></form>
            
        </h3>
        <img width="100%" src="<?php echo e(asset( $item->image)); ?>" alt="">
      </div>

      <div class="modal fade" id="bannerUp<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
    
            <form action="<?php echo e(route('banner.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
    
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Heading</label>
                        <input value="<?php echo e($item->heading); ?>" type="text" name="heading" class="form-control" placeholder="Heading">
                    </div>
                    <input type="hidden" name="slider" value="334" id="">
                    <div class="form-group">
                        <img  width="100%" src="<?php echo e(asset($item->image)); ?>" alt="">
                    </div>
                    <div class="form-group">
                        <label for="">Project Photo</label>
                        <input type="file" class="form-control-file" name="image">
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
                </div>
    
            </form>
        </div>
        </div>
    </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<div class="modal fade" id="banner" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
      <div class="modal-header">
      <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
      </div>

      <form action="<?php echo e(route('banner.store')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>

          <div class="modal-body">
              <div class="form-group">
                  <label for="">Heading</label>
                  <input type="text" name="heading" class="form-control" placeholder="Heading">
              </div>
              <div class="form-group">
                  <label for="">Project Photo</label>
                  <input type="file" class="form-control-file" name="image">
              </div>
          </div>
          <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
          </div>

      </form>
  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/banners.blade.php ENDPATH**/ ?>