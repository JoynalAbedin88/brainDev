<?php $__env->startSection('title'); ?>
    <title>Show Blog Post</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <img src="<?php echo e(asset($banner->image)); ?>" alt="">
        <div class="hero-container" data-aos="fade-up">
            <div>
              <h1 style="font-size: 4em;"><?php echo e($banner->heading); ?></h1>
            </div>
        </div>
      </section>
    <!-- End Hero -->

    <section id="blog">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8 about single-blog">
                    <div class="blog-item mb-5">
                      <div class="video-box d-flex justify-content-center align-items-stretch" style=" background: url(<?php echo e(asset($blog->image)); ?>) center center no-repeat;" data-aos="zoom-in">
                        <?php if($blog->video != Null): ?>
                      <a href="<?php echo e($item->video); ?>" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
                      <?php endif; ?>
                      </div>
                      <div class="content p-5 pt-5">
                          <h4 data-aos="zoom-in"><?php echo e($blog->title); ?></h4>
                          <small data-aos="zoom-in">
                              <strong><?php echo e($blog->category->name); ?> - <?php echo e($blog->created_at->format('F d, Y')); ?> - <?php echo e($blog->comment->count() + $blog->reply->count()); ?> Comments</strong>
                          </small>
                          <?php echo $blog->content; ?>

                        </div>

                        <div class="share-link">
                            <h5>Share This Post</h5>
                            <div class="links">
                                <a href="">
                                    <i class="icofont-twitter"></i>
                                </a>
                                <a href="">
                                    <i class="icofont-facebook"></i>
                                </a>
                                <a href="">
                                    <i class="fab fa-linkedin-in"></i>
                                </a>
                                <a href="">
                                    <i class="fab fa-google-plus-g"></i>
                                </a>
                            </div>
                        </div>
                        <div class="recent-post">
                            <h4>Recent post</h4>
                            <div class="recent-post-slide owl-carousel m-auto" style="width: 80%;">
                                <?php $__currentLoopData = $recent->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="text-dark" href="<?php echo e(route('front.blog.show', ['slug' => $item->slug, 'id' => encrypt($item->id)])); ?>">
                                    <div class="item text-center pb-2">
                                        <img src="<?php echo e(asset($item->image)); ?>" alt="">
                                        <div class="pt-4">
                                            <h6 class="text-dark">Treat Computer System If We Start Project</h6>
                                            <small><?php echo e($item->category->name); ?> - <?php echo e($item->created_at->format('F m, Y')); ?> -  <?php echo e($blog->comment->count() + $blog->reply->count()); ?> Comments</small>
                                        </div>
                                    </div>
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="comment p-3" id="comment-parent">
                            <h4>Comment</h4>
                            <?php $__currentLoopData = $blog->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment-item">
                                <div class="user-img">
                                    <img src="<?php echo e($item->user->image ? asset($item->user->image) : asset('frontend/images/users/user.jpg')); ?>" alt="">
                                </div>
                                <div class="comment-content pb-3">
                                    <h5><?php echo e($item->name); ?></h5>
                                    <span class="time"><?php echo e($item->created_at->diffForHumans()); ?></span>
                                    <p><?php echo e($item->content); ?></p>
                                    <div>
                                        <a class="text-dark"><i class="far fa-thumbs-up"></i>12</a>
                                        <a href="#reply<?php echo e($item->id); ?>" data-toggle="collapse" class="ml-5 text-dark py-2 px-3"><i class="far fa-comment-alt"></i> Reply</a>
                                    </div>
                                </div>
                                <div id="reply<?php echo e($item->id); ?>" class="collapse reply" data-parent="#comment-parent">

                                    
                                    

                                    <?php $__currentLoopData = $item->reply; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="reply-item mt-3">
                                        <div class="user-img">
                                            <img src="<?php echo e($reply->user->image ? asset($reply->user->image) : asset('frontend/images/users/user.jpg')); ?>" alt="">
                                        </div>
                                        <div class="comment-content pb-3">
                                            <h5><?php echo e($reply->name); ?></h5>
                                            <span class="time"><?php echo e($reply->created_at->diffForHumans()); ?></span>
                                            <p><?php echo e($reply->content); ?></p>
                                            <div>
                                                <a class="text-dark"><i class="far fa-thumbs-up"></i>12</a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    
                                    
                                    <?php if(auth()->guard()->check()): ?>
                                    <div class="reply-item mt-3">
                                        <div class="comment-item">
                                            <div class="user-img">
                                                <img src="<?php echo e(Auth::user()->image != Null ? asset(Auth::user()->image) : asset('frontend/images/users/user.jpg')); ?>" alt="">
                                            </div>
                                            <div class="comment-content pb-3">
                                                <form action="<?php echo e(route('reply.store')); ?>" method="POST"> <?php echo csrf_field(); ?>
                                                    <div class="row">
                                                        <div class="col-md-6 col-12 form-group">
                                                            <input type="text" class="form-control" name="name" placeholder="Your Name" value="<?php echo e($save ? $save->name :''); ?>">
                                                        </div>

                                                        <div class="col-md-6 col-12 form-group">
                                                            <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e($save ? $save->email :''); ?>">
                                                        </div>

                                                        

                                                        <div class="col-md-6 col-12 form-group">
                                                            <input type="text" name="phone" class="form-control" placeholder="Phone Number" value="<?php echo e($save ? $save->phone :''); ?>">
                                                        </div>

                                                        <div class="col-md-6 col-12 form-group">
                                                            <input name="company" type="text" class="form-control" placeholder="Company Name" <?php echo e($save ? $save->company :''); ?>>
                                                        </div>
                                                        <div class="col-12 form-group">
                                                            <textarea name="comment" id="" cols="30" rows="5" class="form-control" placeholder="Your Comment"><?php echo e(old('comment')); ?></textarea>
                                                        </div>
                                                        <?php
                                                            $data = session(['post' => encrypt($blog->id)]);
                                                        ?>
                                                        <input type="hidden" name="comment_id" value="<?php echo e(encrypt($item->id)); ?>">
                                                        <div class="form-group col-md-6 col-12">
                                                            <button type="submit" class="btn btn-primary">Post Comment</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if(auth()->guard()->check()): ?>
                            <div class="comment-item">
                                <div class="user-img">
                                    <img src="<?php echo e(Auth::user()->image != Null ? asset(Auth::user()->image) : asset('frontend/images/users/user.jpg')); ?>" alt="">
                                </div>
                                <div class="comment-content pb-3">
                                    <form action="<?php echo e(route('comment.store')); ?>" method="POST"> <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="col-md-6 col-12 form-group">
                                                <input type="text" class="form-control" name="name" placeholder="Your Name" value="<?php echo e($save ? $save->name :''); ?>">
                                            </div>
                                            <div class="col-md-6 col-12 form-group">
                                                <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e($save ? $save->email :''); ?>">
                                            </div>
                                            <div class="col-12 form-group">
                                                <label for="save">
                                                    <input type="checkbox" id="save" class="form-control-checkbox" <?php echo e($save ? 'checked' :''); ?> name="save" value="save">
                                                    <small>Save my name, email, and website in this browser for the next time I comment.</small>
                                                </label>
                                                
                                            </div>
                                            <div class="col-md-6 col-12 form-group">
                                                <input type="text" name="phone" class="form-control" placeholder="Phone Number" value="<?php echo e($save ? $save->phone :''); ?>">
                                            </div>
                                            <div class="col-md-6 col-12 form-group">
                                                <input name="company" type="text" class="form-control" placeholder="Company Name" value="<?php echo e($save ? $save->company :''); ?>">
                                            </div>
                                            <div class="col-12 form-group">
                                                <textarea name="comment" id="" cols="30" rows="5" class="form-control" placeholder="Your Comment"><?php echo e(old('comment')); ?></textarea>
                                            </div>
                                            <?php
                                                $data = session(['post' => encrypt($blog->id)]);
                                            ?>
                                            <div class="form-group col-md-6 col-12">
                                                <button type="submit" class="btn btn-primary">Post Comment</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <?php endif; ?>

                        </div>
                    </div>


                </div>
                <div id="catagory-bar" class="col-12 col-md-4">
                    <div class="blog-search">
                        <form action="<?php echo e(route('blog.index')); ?>" method="get">
                          <div class="search-box">
                            <input type="text" name="search" class="form-control" placeholder="Serach Here">
                            <button type="submit"><i class="fas fa-search"></i></button>
                          </div>
                        </form>
                    </div>

                    <div class="catagory">
                      <div class="text-center">
                        <h3>Catagories</h3>
                      </div>
                      <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <a href="<?php echo e(route('front.blog.category', encrypt($item->id))); ?>"> <?php echo e($item->name); ?></a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="feature-post">
                        <?php $__currentLoopData = $recent->limit(6)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <a href="<?php echo e(route('front.blog.show', ['slug' => $item->slug, 'id' => encrypt($item->id)])); ?>">
                              <div class="img float-left">
                                <img src="<?php echo e(asset($item->image)); ?>" alt="">
                              </div>
                              <div class="content">
                                <h6><?php echo e(substr($item->title, 0, 25)); ?> ...</h6>
                                <small><?php echo e($item->category->name); ?> - <?php echo e($item->created_at->format('F m, Y')); ?></small>
                              </div>
                            </a>
                          </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="calendar">
                      <div style="position: relative;">
                        <h3 id="monthAndYear"></h3>

                        <div class="nxt-prev">
                          <button id="previous" onclick="previous()"><i class="fas fa-chevron-left"></i></button>
                          <button id="next" onclick="next()"><i class="fas fa-chevron-right"></i></button>
                        </div>

                      </div>
                      <table class="table table-bordered text-center">
                        <thead>
                          <tr>
                            <th scope="col">Mo</th>
                            <th scope="col">Tu</th>
                            <th scope="col">We</th>
                            <th scope="col">Th</th>
                            <th scope="col">Fr</th>
                            <th scope="col">Sa</th>
                            <th scope="col">Su</th>
                          </tr>
                        </thead>
                        <tbody id="calendar-body">

                        </tbody>
                      </table>
                    </div>
                </div>
            </div>
        </div>
        
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/frontend/singleBlog.blade.php ENDPATH**/ ?>