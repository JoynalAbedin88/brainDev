<?php $__env->startSection('title'); ?>
    <title>Add Post</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/19.0.0/classic/ckeditor.js"></script>
<div class="app-title">
    <div>
        <h1>Create Category</h1>
        <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>
<section>
    <div class="container">

       <div class="row">
            <div class="col-12 col-md-10 m-auto">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <div class="text-left my-3">
                    <a href="#memberAdd" data-toggle="modal" class="btn btn-primary">Add New Category</a>
                </div>
                <table class="table table-striped table-hover text-center">
                    <thead>
                        <tr>
                            <th colspan="4"><h5>Our Team Leaders</h5></th>
                        </tr>
                        <tr>
                            <th>S\L</th>
                            <th>Name</th>
                            <th>Image</th>
                            <th>Designation</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($k+1); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><img width="50" src="<?php echo e(asset($item->image)); ?>" alt=""></td>
                            <td><?php echo e($item->designation); ?></td>
                            <td>
                                <a href="#update<?php echo e($item->id); ?>" data-toggle="modal" class="btn btn-primary">Update</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </tbody>
               </table>

               <table class="table table-striped table-hover text-center">
                <thead>
                    <tr>
                        <th colspan="4"><h5>Our Experienced Experts</h5></th>
                    </tr>
                    <tr>
                        <th>S\L</th>
                        <th>Name</th>
                        <th>Image</th>
                        <th>Designation</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($k+1); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><img width="50" src="<?php echo e(asset($item->image)); ?>" alt=""></td>
                            <td><?php echo e($item->designation); ?></td>
                            <td>
                                <a href="#update<?php echo e($item->id); ?>" data-toggle="modal" class="btn btn-primary">Update</a>
                            </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
           </table>
            </div>
       </div>
       <!-- Modal -->
        <div class="modal fade" id="memberAdd" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>

                <form action="<?php echo e(route('team.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <label for="name">Member Image</label>
                            <input type="file" id="image" class="form-control-file" name="image">
                        </div>
                        <div class="form-group">
                            <label for="name">Member Name</label>
                            <input type="text" id="name" class="form-control" name="name" placeholder="name">
                        </div>
                        <div class="form-group">
                            <label for="designation">Designation</label>
                            <input type="text" id="designation" class="form-control" name="designation" placeholder="Designation">
                        </div>
                        <div class="form-group text-left">
                            <label for="leader">
                            <input type="checkbox" id="leader" class="form-control-checkbox" name="leader" value="2">
                            Make Team Leader
                        </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                    </div>

                </form>
            </div>
            </div>
        </div>

        <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="update<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>

                <form action="<?php echo e(route('team.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>

                    <div class="modal-body">
                        <div class="form-group text-center">
                            <img width="150" src="<?php echo e(asset($item->image)); ?>" alt="">
                        </div>
                        <div class="form-group">
                            <label for="name">Member Image</label>
                            <input type="file" id="image" class="form-control-file" name="image">
                        </div>
                        <div class="form-group">
                            <label for="name">Member Name</label>
                            <input type="text" id="name" class="form-control" name="name" placeholder="name" value="<?php echo e($item->name); ?>">
                        </div>
                        <div class="form-group">
                            <label for="designation">Designation</label>
                            <input type="text" id="designation" class="form-control" name="designation" placeholder="Designation" value="<?php echo e($item->designation); ?>">
                        </div>
                        <div class="form-group text-left">
                            <label for="leader">
                            <input type="checkbox" id="leader" <?php echo e($item->status == 2 ? 'checked' : ''); ?> class="form-control-checkbox" name="leader" value="2">
                            Make Team Leader
                        </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                    </div>

                </form>
            </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<script>
        .create( document.querySelector( '#content' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $('#name').keyup(function() {
			  $('#slug').val($(this).val().toLowerCase().split(',').join('').replace(/\s/g,"-"));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/team.blade.php ENDPATH**/ ?>