@include('frontend.layouts.header')
    <main id="main">
       @yield('content')
    </main>
    <!-- End #main -->
 @include('frontend.layouts.footer')