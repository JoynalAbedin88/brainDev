<?php $__env->startSection('ttile'); ?>
    <title>Create Home</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
    <h1> Create banner</h1>
    <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>
<section>
    <div class="container">
        <div class="col-12">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <h2>Header Section 1</h2>
            <form action="<?php echo e($section_1 ? route('home.update', $section_1->id) : route('home.store')); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php if($section_1): ?> <?php echo method_field('put'); ?> <?php endif; ?>
                <div class="row">
                    <div class="form-group col-12">
                        <label for="heading">Heading Content</label>
                        <input type="text" id="heading" name="heading" class="form-control" placeholder="section_1 Heading" value="<?php echo e($section_1 ? $section_1->heading : ''); ?>">
                    </div>
                    <input type="hidden" value="1" name="section">
                    
                   <div class="row col-12">
                    <div class="form-group col-4 col-md-3 m-auto">
                        <?php if($section_1): ?>
                        <img width="100%" src="<?php echo e(asset($section_1->img_1)); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-4 col-md-3 m-auto">
                        <?php if($section_1): ?>
                        <img width="100%" src="<?php echo e(asset($section_1->img_2)); ?>" alt="">
                        <?php endif; ?>
                    </div>
                   </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="">Chose First Image</label>
                        <input type="file" class="form-control-file" name="first_img">
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="">Chose Second Image</label>
                        <input type="file" class="form-control-file" name="second_img">
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="upper_pra">First Pragraph</label>
                        <textarea name="upper_pra" class="form-control" id="upper_pra" cols="30" rows="5" placeholder="First Pragraph"><?php echo e($section_1 ? $section_1->pragraph_1 : ''); ?></textarea>
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="lower_pra">Second Pragraph</label>
                        <textarea name="lower_pra" class="form-control" id="lower_pra" cols="30" rows="5" placeholder="Second Pragraph"><?php echo e($section_1 ? $section_1->pragraph_2 : ''); ?></textarea>
                    </div>
                    <div class="form-group col-12">
                        <button class="btn btn-primary px-5" type="submit">Save</button>
                    </div>
                </div>
            </form>

            <h2>Header Section 2</h2>
            <form action="<?php echo e($section_2 ? route('home.update', $section_2->id) : route('home.store')); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php if($section_2): ?> <?php echo method_field('put'); ?> <?php endif; ?>
                <div class="row">
                    <div class="form-group col-12">
                        <label for="heading">Heading Content</label>
                        <input type="text" id="heading" name="heading" class="form-control" placeholder="section_1 Heading" value="<?php echo e($section_2 ? $section_2->heading : ''); ?>">
                    </div>
                    <input type="hidden" value="2" name="section">
                    
                   <div class="row col-12">
                    <div class="form-group col-4 col-md-3 m-auto">
                        <?php if($section_2): ?>
                        <img width="100%" src="<?php echo e(asset($section_2->img_1)); ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="form-group col-4 col-md-3 m-auto">
                        <?php if($section_2): ?>
                        <img width="100%" src="<?php echo e($section_2 ? asset($section_2->img_2) : ''); ?>" alt="">
                        <?php endif; ?>
                    </div>
                   </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="">Chose First Image</label>
                        <input type="file" class="form-control-file" name="first_img">
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="">Chose Second Image</label>
                        <input type="file" class="form-control-file" name="second_img">
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="upper_pra">First Pragraph</label>
                        <textarea name="upper_pra" class="form-control" id="upper_pra" cols="30" rows="5" placeholder="First Pragraph"><?php echo e($section_2 ? $section_2->pragraph_1 : ''); ?></textarea>
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="lower_pra">Second Pragraph</label>
                        <textarea name="lower_pra" class="form-control" id="lower_pra" cols="30" rows="5" placeholder="Second Pragraph"><?php echo e($section_2 ? $section_2->pragraph_2 : ''); ?></textarea>
                    </div>
                    <div class="form-group col-12">
                        <button class="btn btn-primary px-5" type="submit">Save</button>
                    </div>
                </div>
            </form>

            <h2>Video Section</h2>
            <form action="<?php echo e($section_3 ? route('home.update', $section_3->id) : route('home.store')); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php if($section_3): ?> <?php echo method_field('put'); ?> <?php endif; ?>
                <div class="row">
                    <div class="form-group col-12">
                        <label for="heading">Heading Content</label>
                        <input type="text" id="heading" name="heading" class="form-control" placeholder="section_1 Heading" value="<?php echo e($section_3 ? $section_3->heading : ''); ?>">
                    </div>
                    <input type="hidden" value="3" name="section">
                    
                   <div class="row col-12">
                    <div class="form-group col-6 col-md-4 m-auto">
                        <?php if($section_2): ?>
                        <img width="100%" src="<?php echo e($section_3 ? asset( $section_3->img_1)  : ''); ?>" alt="">
                        <?php endif; ?>
                    </div>
                   </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="">Chose Second Image</label>
                        <input type="file" class="form-control-file" name="first_img">
                    </div>
                    <div class="form-group col-12 col-md-6">
                        <label for="">Your Video link <a target="_blank" href="<?php echo e($section_3 ? $section_3->video : ''); ?>">play video</a></label>
                        <input type="text" class="form-control" name="video" placeholder="Video link">
                    </div>
                    <div class="form-group col-12">
                        <label for="upper_pra">First Pragraph</label>
                        <textarea name="upper_pra" class="form-control" id="upper_pra" cols="30" rows="5" placeholder="First Pragraph"><?php echo e($section_3 ? $section_3->pragraph_1 : ''); ?></textarea>
                    </div>
                    <div class="form-group col-12">
                        <button class="btn btn-primary px-5" type="submit">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/createHome.blade.php ENDPATH**/ ?>