<?php $__env->startSection('title'); ?>
    <title>Project</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- ======= Hero Section ======= -->
    <section id="hero">
        <img src="<?php echo e(asset($banner->image)); ?>" alt="">
        <div class="hero-container" data-aos="fade-up">
            <div>
              <h1 style="font-size: 4em;"><?php echo e($banner->heading); ?></h1>
            </div>
        </div>
      </section>
    <!-- End Hero -->

    <section id="latest-project">
        <div class="container">
            <div class="section-title" data-aos="zoom-in">
                <h3 style="color:#033862">Our Latest Projects</h3>
                <p>There are more latest project done yet.</p>
            </div>
            <div class="row latest-ptoject owl-carousel">
                <?php $__currentLoopData = $latest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <div class="project-item">
                    <span><?php echo e($item->category ? $item->category->name : ''); ?></span>
                    <img src="<?php echo e(asset($item->image)); ?>" alt="">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- ======= About Section ======= -->
       <!-- ======= Portfolio Section ======= -->
       <section id="portfolio" class="portfolio pt-2">
        <div class="container">
  
          <div class="section-title" data-aos="zoom-in">
            <h3>Our Projects</h3>
          </div>
  
          <div class="row">
            <div class="col-lg-12 d-flex justify-content-center" data-aos="fade-up">
              <ul id="portfolio-flters">
                <li data-filter="*" class="filter-active">All Works</li>
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-filter=".filter<?php echo e($item->id); ?>"><?php echo e($item->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          </div>
  
          <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="100">

            <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 portfolio-item filter<?php echo e($item->category_id); ?>">
                <img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" alt="">
                <div class="portfolio-info">
                  <h5><?php echo e($item->category ? $item->category->name : ''); ?></h5>
                  
                </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
          </div>
  
        </div>
      </section>

    <!-- ======= team ======= -->
    <section id="com-prortfolio" class="pt-2">
        <div class="container">
            <div class="section-title" data-aos="zoom-in">
                <h3 style="color:#033862">The Complete Portfolio</h3>
                <p>Make an engaging magazine yet flexible, fast and lightweight website with the power
                    of Outsourceo exclusive magazine Elementor elements.</p>
            </div>
            <div style="width:70%" class="m-auto">
                <div class="com-prortfolio owl-carousel">
                    <?php $__currentLoopData = $complete; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="">
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/frontend/project.blade.php ENDPATH**/ ?>