
<script src="<?php echo e(asset('backend/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/layouts/footer.blade.php ENDPATH**/ ?>