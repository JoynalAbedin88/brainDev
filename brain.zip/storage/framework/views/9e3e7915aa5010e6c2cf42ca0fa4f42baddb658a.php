<?php $__env->startSection('title'); ?>
    <title><?php echo e($about ?'Update':'Create'); ?>-About</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="app-title">
        <div>
        <h1> <?php echo e($about ?'Update':'Create'); ?> About</h1>
        <p>A free and open source Bootstrap 4 admin template</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
        </ul>
    </div>
    <section>
        <div class="container">
            <div class="col-12">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e($about ? route('about.update', $about->id) : route('about.store')); ?>" method="POST" enctype="multipart/form-data"> <?php echo csrf_field(); ?> <?php if($about): ?> <?php echo method_field('put'); ?> <?php endif; ?>
                    <div class="row">
                        <div class="form-group col-12">
                            <?php if($about): ?>
                            <img width="100%" src="<?php echo e(asset($about->banner)); ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="">Chose Banner</label>
                            <input type="file" class="form-control-file" name="banner">
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="heading">Heading Content</label>
                            <input type="text" id="heading" name="heading" class="form-control" placeholder="About Heading" value="<?php echo e($about ? $about->heading : ''); ?>">
                        </div>
                       <div class="row col-12">
                        <div class="form-group col-4 col-md-3 m-auto">
                            <?php if($about): ?>
                            <img width="100%" src="<?php echo e(asset($about->upper_img)); ?>" alt="">
                            <?php endif; ?>
                        </div>
                        <div class="form-group col-4 col-md-3 m-auto">
                            <?php if($about): ?>
                            <img width="100%" src="<?php echo e(asset($about->lower_img)); ?>" alt="">
                            <?php endif; ?>
                        </div>
                       </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="">Chose First Image</label>
                            <input type="file" class="form-control-file" name="first_img">
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="">Chose Second Image</label>
                            <input type="file" class="form-control-file" name="second_img">
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="upper_pra">First Pragraph</label>
                            <textarea name="upper_pra" class="form-control" id="upper_pra" cols="30" rows="5" placeholder="First Pragraph"><?php echo e($about ? $about->upper_pra : ''); ?></textarea>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="lower_pra">Second Pragraph</label>
                            <textarea name="lower_pra" class="form-control" id="lower_pra" cols="30" rows="5" placeholder="Second Pragraph"><?php echo e($about ? $about->lower_pra : ''); ?></textarea>
                        </div>
                        <div class="form-group col-12">
                            <button class="btn btn-primary px-5" type="submit">Save</button>
                            <a href="<?php echo e(route('blog.index')); ?>" class="btn btn-warning px-4" target="_blank">Page Preview</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/creteAbout.blade.php ENDPATH**/ ?>