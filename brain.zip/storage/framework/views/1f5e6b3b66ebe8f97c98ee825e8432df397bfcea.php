<?php $__env->startSection('title'); ?>
    <title>Add Post</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="app-title">
    <div>
        <h1>Create Blog Post</h1>
        <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>
<section>
    <div class="container">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('blog.store')); ?>" method="post" enctype="multipart/form-data"> <?php echo csrf_field(); ?>
            <div class="row p-4">
                <div class="form-group col-12 col-md-6">
                    <label for="title">Post Title</label>
                    <input type="text" name="title" value="<?php echo e(old('title')); ?>" id="title" class="form-control" placeholder="Title">
                    <input type="hidden" name="slug" value="<?php echo e(old('slug')); ?>" id="slug">
                </div>

                <div class="form-group col-12 col-md-6">
                    <label for="">Post Type</label>
                    <select class="form-control" name="type" >
                        <option value="" disabled selected>Select Post Type</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e(encrypt($item->id)); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-12 col-md-6 form-group">
                    <label for="">Image</label>
                    <input type="file" class="form-control-file" name="file">
                </div>

                <div class="col-12 col-md-6 form-group">
                    <label for="video">Only Youtube video link</label>
                    <input type="text" id="video" class="form-control" name="video"  placeholder="Video link" value="<?php echo e(old('video')); ?>">
                </div>

                <div class="col-12 form-group">
                    <label for="content">Post Content</label>
                    <textarea name="content" id="content" class="form-control"><?php echo old('content'); ?></textarea>
                </div>

                <div class="col-12 form-group">
                    <button type="submit" class='btn btn-primary px-4'>Post Submit</button>
                </div>
            </div>
        </form>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/19.0.0/classic/ckeditor.js"></script>
<script>
        $('#title').keyup(function() {
			  $('#slug').val($(this).val().toLowerCase().split(',').join('').replace(/\s/g,"-"));
        });
</script>
<script>
    ClassicEditor
        .create( document.querySelector( '#content' ) )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/blog/create.blade.php ENDPATH**/ ?>