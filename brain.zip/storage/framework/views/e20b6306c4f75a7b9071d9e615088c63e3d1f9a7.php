<?php $__env->startSection('title'); ?>
    <title>Edit Service</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
    <h1>Create Services</h1>
    <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>
<section>
    <div class="container">
        <div class="row">
            <div class="col-12 col-md-10 m-auto">
                <form action="<?php echo e(route('service.update', $service->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>  <?php echo method_field('put'); ?>
                    <div class="row">
                        <div class="col-12 text-center mb-3">
                            <img class="bg-primary p-2" src="<?php echo e(asset($service->icon)); ?>" alt="">
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="Name">Service Name</label>
                            <input placeholder="Service Name" type="text" id="Name" class="form-control" name="name" value="<?php echo e($service->name); ?>">
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="Price">Price</label>
                            <input placeholder="Price" type="number" id="Price" class="form-control" name="price" value="<?php echo e($service->price); ?>">
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="Name">Service Type</label>
                            <select name="type" class="form-control" >
                                <option value="" selected disabled>Select Service Type</option>
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e(encrypt($item->id)); ?>" <?php echo e($service->category_id == $item->id ? 'selected' :''); ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group col-12 col-md-6">
                            <label for="icon">Icon</label>
                            <input type="file" class="form-control-file" name="icon">
                        </div>
                        <div class="form-group col-12">
                            <label for="special">
                                <input type="checkbox" <?php echo e($service->special == 1 ? 'checked' : ''); ?> id="special" value="12" class="form-control-checkbox" name="special">
                                Make Special
                            </label>
                        </div>
                        <div class="form-group col-12">
                            <label for="desc">Description (Please use # to show step by step)</label>
                            <textarea name="desc" id="desc" cols="30" rows="5" class="form-control" placeholder="description"><?php echo e($service->description); ?></textarea>
                        </div>
                    </div>
                    <div class="">
                    <button type="submit" class="btn btn-primary">Save</button>
                    <a href="<?php echo e(route('service.create')); ?>" class="btn btn-warning">Back</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/editService.blade.php ENDPATH**/ ?>