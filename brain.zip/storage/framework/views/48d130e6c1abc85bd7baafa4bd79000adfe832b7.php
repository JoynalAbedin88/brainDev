<?php $__env->startSection('title'); ?>
    <title>Banner Create</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="app-title">
    <div>
    <h1> Create banner</h1>
    <p>A free and open source Bootstrap 4 admin template</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
    <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
    </ul>
</div>
    <section >
        <a href="#banner" data-toggle="modal" class="btn btn-primary">Add New Banner</a>
        <table class="table text-center">
            <thead>
              <tr>
                <th scope="col">Photo</th>
                <th scope="col">Heading</th>
                <th scope="col">Short Paragraph</th>
                <th scope="col">Slider</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th>
                        <img width="200" src="<?php echo e(asset($item->image)); ?>" alt="">
                    </th>
                    <td><?php echo e($item->heading); ?></td>
                    <td><?php echo e($item->short); ?></td>
                    <?php if($item->status==1): ?>
                    <td><a href="<?php echo e(route('banner.show', $item->id)); ?>" class="btn btn-primary"><i class="fas fa-check"></i></a></td>
                    <?php else: ?>
                    <td><a href="<?php echo e(route('banner.show', $item->id)); ?>" class="btn btn-danger"><i class="fas fa-times"></i></a></td>
                    <?php endif; ?>
                    <td>
                        <a href="#banner<?php echo e($item->id); ?>" data-toggle="modal" class="btn btn-primary"><i class="fas fa-edit"></i></a>
                        <a href="<?php echo e(route('banner.destroy', $item->id)); ?>" onclick="event.preventDefault();
                                        document.getElementById('delete<?php echo e($item->id); ?>').submit()" class="btn btn-warning"><i class="fas fa-trash-alt"></i></a>
                    </td>
                    <form action="<?php echo e(route('banner.destroy', $item->id)); ?>" id="delete<?php echo e($item->id); ?>" method="POST"> <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?></form>
                </tr>

                <div class="modal fade" id="banner<?php echo e($item->id); ?>" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
                    <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                        <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                        </div>
                
                        <form action="<?php echo e(route('banner.update', $item->id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> <?php echo method_field('put'); ?>
                
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="">Heading</label>
                                    <input value="<?php echo e($item->heading); ?>" type="text" name="heading" class="form-control" placeholder="Heading">
                                </div>
                                <div class="form-group">
                                    <label for="">Short Paragraph</label>
                                    <input value="<?php echo e($item->short); ?>" type="text" name="short" class="form-control" placeholder="Short Paragraph">
                                </div>
                                <input type="hidden" name="slider" value="334" id="">
                                <div class="form-group">
                                    <img  width="100%" src="<?php echo e(asset($item->image)); ?>" alt="">
                                </div>
                                <div class="form-group">
                                    <label for="">Project Photo</label>
                                    <input type="file" class="form-control-file" name="image">
                                </div>
                            </div>
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save</button>
                            </div>
                
                        </form>
                    </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
    </section>

    <div class="modal fade" id="banner" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addNewAboutLabel" aria-hidden="true">
        <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h5 class="modal-title" id="addNewAboutLabel">About Section Content</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            </div>
    
            <form action="<?php echo e(route('banner.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
    
                <div class="modal-body">
                    <div class="form-group">
                        <label for="">Heading</label>
                        <input type="text" name="heading" class="form-control" placeholder="Heading">
                    </div>
                    <div class="form-group">
                        <label for="">Short Paragraph</label>
                        <input type="text" name="short" class="form-control" placeholder="Short Paragraph">
                    </div>
                    <input type="hidden" name="slider" value="334" id="">
                    <div class="form-group">
                        <label for="">Project Photo</label>
                        <input type="file" class="form-control-file" name="image">
                    </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save</button>
                </div>
    
            </form>
        </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/abedin/Company/brainShare/resources/views/backend/slider.blade.php ENDPATH**/ ?>